﻿namespace Backgammon;

internal class Field
{
    Stack<Checker> checkersOnField = new Stack<Checker>();
}
