﻿namespace Backgammon;

internal class Player
{
}
