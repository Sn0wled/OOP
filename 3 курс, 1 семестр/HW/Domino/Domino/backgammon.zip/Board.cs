﻿namespace Backgammon;

internal class Board
{
    Field[] fields = new Field[24];
}
