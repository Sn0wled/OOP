﻿namespace Backgammon;

internal class Checker
{

}
