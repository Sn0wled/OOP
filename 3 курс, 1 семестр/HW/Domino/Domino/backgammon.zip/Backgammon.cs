﻿namespace Backgammon;

internal class Backgammon
{
    Board board = new Board();
    Player player1, player2;
    Player walkingPlayer; // ??
    Dice dice1, dice2;
    int moveCounter = 0;
}
